<?php
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "sekolahhebat";
	
	$conn = new mysqli($host, $user, $pass, $db);
	if($conn->connect_error){
		echo "Gagal koneksi ke database:" . $conn->connect_error;
	}
?>