-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2024 at 04:17 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sekolahhebat`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`) VALUES
(1, 'Admin', '', 'admin@mail.com', 'D00F5D5217896FB7FD601412CB890830');

-- --------------------------------------------------------

--
-- Table structure for table `tblattendance`
--

CREATE TABLE `tblattendance` (
  `Id` int(10) NOT NULL,
  `admissionNo` varchar(255) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `sessionTermId` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `dateTimeTaken` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblattendance`
--

INSERT INTO `tblattendance` (`Id`, `admissionNo`, `classId`, `classArmId`, `sessionTermId`, `status`, `dateTimeTaken`) VALUES
(162, 'ASDFLKJ', '1', '2', '1', '1', '2020-11-01'),
(163, 'HSKSDD', '1', '2', '1', '1', '2020-11-01'),
(164, 'JSLDKJ', '1', '2', '1', '1', '2020-11-01'),
(172, 'HSKDS9EE', '1', '4', '1', '1', '2020-11-01'),
(171, 'JKADA', '1', '4', '1', '0', '2020-11-01'),
(170, 'JSFSKDJ', '1', '4', '1', '1', '2020-11-01'),
(173, 'ASDFLKJ', '1', '2', '1', '1', '2020-11-19'),
(174, 'HSKSDD', '1', '2', '1', '1', '2020-11-19'),
(175, 'JSLDKJ', '1', '2', '1', '1', '2020-11-19'),
(176, 'JSFSKDJ', '1', '4', '1', '0', '2021-07-15'),
(177, 'JKADA', '1', '4', '1', '0', '2021-07-15'),
(178, 'HSKDS9EE', '1', '4', '1', '0', '2021-07-15'),
(179, 'ASDFLKJ', '1', '2', '1', '0', '2021-09-27'),
(180, 'HSKSDD', '1', '2', '1', '1', '2021-09-27'),
(181, 'JSLDKJ', '1', '2', '1', '1', '2021-09-27'),
(182, 'ASDFLKJ', '1', '2', '1', '0', '2021-10-06'),
(183, 'HSKSDD', '1', '2', '1', '0', '2021-10-06'),
(184, 'JSLDKJ', '1', '2', '1', '1', '2021-10-06'),
(185, 'ASDFLKJ', '1', '2', '1', '0', '2021-10-07'),
(186, 'HSKSDD', '1', '2', '1', '0', '2021-10-07'),
(187, 'JSLDKJ', '1', '2', '1', '0', '2021-10-07'),
(188, 'AMS110', '4', '6', '1', '1', '2021-10-07'),
(189, 'AMS133', '4', '6', '1', '0', '2021-10-07'),
(190, 'AMS135', '4', '6', '1', '0', '2021-10-07'),
(191, 'AMS144', '4', '6', '1', '1', '2021-10-07'),
(192, 'AMS148', '4', '6', '1', '0', '2021-10-07'),
(193, 'AMS151', '4', '6', '1', '1', '2021-10-07'),
(194, 'AMS159', '4', '6', '1', '1', '2021-10-07'),
(195, 'AMS161', '4', '6', '1', '1', '2021-10-07'),
(196, 'AMS110', '4', '6', '1', '1', '2022-06-06'),
(197, 'AMS133', '4', '6', '1', '0', '2022-06-06'),
(198, 'AMS135', '4', '6', '1', '0', '2022-06-06'),
(199, 'AMS144', '4', '6', '1', '1', '2022-06-06'),
(200, 'AMS148', '4', '6', '1', '0', '2022-06-06'),
(201, 'AMS151', '4', '6', '1', '1', '2022-06-06'),
(202, 'AMS159', '4', '6', '1', '1', '2022-06-06'),
(203, 'AMS161', '4', '6', '1', '1', '2022-06-06');

-- --------------------------------------------------------

--
-- Table structure for table `tblguru`
--

CREATE TABLE `tblguru` (
  `Id` int(10) NOT NULL,
  `nip` varchar(10) NOT NULL,
  `namaBelakang` varchar(255) NOT NULL,
  `emailGuru` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `noTelepon` varchar(50) NOT NULL,
  `idKelas` varchar(10) NOT NULL,
  `kodeKelas` varchar(255) NOT NULL,
  `tahunMasuk` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblguru`
--

INSERT INTO `tblguru` (`Id`, `nip`, `namaBelakang`, `emailGuru`, `password`, `noTelepon`, `idKelas`, `kodeKelas`, `tahunMasuk`) VALUES
(1, '123456789', 'Budi Santoso', 'budi.santoso@gmail.com', '32250170a0dca92d53ec9624f336ca24', '087654321098', '1', '2', '2023-10-31'),
(8, '234567890', 'Siti Rahayu', 'siti.rahayu@gmail.com', '32250170a0dca92d53ec9624f336ca24', '089012345678', '4', '6', '2024-1-13'),
(5, '654321098', 'Joko Prasetyo', 'joko.prasetyo@gmail.com', '32250170a0dca92d53ec9624f336ca24', '7014560000', '3', '5', '2023-10-07'),
(6, '890123456', 'Dewi Indah Sari', 'dewi.indah.sari@gmail.com', '32250170a0dca92d53ec9624f336ca24', '087654321098', '4', '6', '2022-10-07'),
(7, '987654321', 'Ani Wulandari', 'ani.wulandari@gmail.com', '32250170a0dca92d53ec9624f336ca24', '081234567890', '1', 'C', '2024-01-13'),
(9, '2223343434', 'Sakima Nur Sawa', 'Sakima@email.com', '32250170a0dca92d53ec9624f336ca24', '08232355333', '5', 'C', '2024-02-05'),
(10, '654321235', 'Saya Suyatna', 'sayayes@gmail.com', '32250170a0dca92d53ec9624f336ca24', '089012345678', '7', '', '2024-02-09'),
(11, '1372783254', 'Masuke Irawan', 'Masuke@gmail.com', '32250170a0dca92d53ec9624f336ca24', '08245447344', '7', '', '2024-02-09'),
(12, '1234567452', 'Amara Santi', 'Amar@gmail.com', '32250170a0dca92d53ec9624f336ca24', '082435563687', '6', '', '2024-02-09'),
(13, '2124555667', 'Syahrul Aman', 'Syahrul@gmail.com', '32250170a0dca92d53ec9624f336ca24', '0812223455654', '6', '', '2024-02-09'),
(14, '134222534', 'Bagas  Syahputra', 'Bagas@gmail.com', '32250170a0dca92d53ec9624f336ca24', '0865554321', '4', '', '2024-02-09'),
(15, '1223235554', 'Daffa Antana', 'Daffa@gmail.com', '32250170a0dca92d53ec9624f336ca24', '0856432241', '3', '', '2024-02-09'),
(16, '142333567', 'Sopian Manada', 'Sopian@gmail.com', '32250170a0dca92d53ec9624f336ca24', '0852324471', '3', '', '2024-02-09'),
(17, '1223352221', 'Agus Rafata', 'Agus@gmail.com', '32250170a0dca92d53ec9624f336ca24', '086452231', '1', '', '2024-02-09');

-- --------------------------------------------------------

--
-- Table structure for table `tblkelas`
--

CREATE TABLE `tblkelas` (
  `Id` int(10) NOT NULL,
  `namaKelas` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblkelas`
--

INSERT INTO `tblkelas` (`Id`, `namaKelas`) VALUES
(1, 'Satu 1'),
(3, 'Dua 2'),
(4, 'Tiga 3'),
(5, 'Empat 4'),
(6, 'Lima 5'),
(7, 'Enam 6'),
(8, 'Tujuh 7');

-- --------------------------------------------------------

--
-- Table structure for table `tblkodekelas`
--

CREATE TABLE `tblkodekelas` (
  `Id` int(10) NOT NULL,
  `idKelas` varchar(10) NOT NULL,
  `kodeKelas` varchar(255) NOT NULL,
  `kodeMasuk` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblkodekelas`
--

INSERT INTO `tblkodekelas` (`Id`, `idKelas`, `kodeKelas`, `kodeMasuk`) VALUES
(2, '1', 'A', '1'),
(4, '1', 'B', '1'),
(5, '3', 'C', '1'),
(6, '4', 'D', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tblmurid`
--

CREATE TABLE `tblmurid` (
  `Id` int(10) NOT NULL,
  `nis` varchar(10) NOT NULL,
  `namaMurid` varchar(255) NOT NULL,
  `kodeAdmisi` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `idKelas` varchar(10) NOT NULL,
  `tingkatKelas` varchar(10) NOT NULL,
  `dataMasuk` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmurid`
--

INSERT INTO `tblmurid` (`Id`, `nis`, `namaMurid`, `kodeAdmisi`, `password`, `idKelas`, `tingkatKelas`, `dataMasuk`) VALUES
(1, '112233445', 'Rina Fitriani', 'AMS005', '12345', '1', '2', '2022-10-31'),
(3, '556677889', 'Dian Pratama', 'AMS007', '12345', '1', '2', '2022-10-31'),
(4, '990011223', 'Maya Dewi', 'AMS011', '12345', '1', '2', '2022-10-31'),
(5, '334455667', 'Farhan Akbar', 'AMS012', '12345', '1', '4', '2022-10-31'),
(6, '778899001', 'Sari Indah', 'AMS015', '12345', '1', '4', '2022-10-31'),
(7, '112233446', 'Rudi Santoso', 'AMS017', '12345', '1', '4', '2022-10-31'),
(8, '556677890', 'Ika Puspita', 'AMS019', '12345', '3', '5', '2022-10-31'),
(9, '990011224', 'Dwi Prasetyo', 'AMS021', '12345', '3', '5', '2022-10-31'),
(10, '334455668', 'Rina Wahyuni', 'AMS110', '12345', '4', '6', '2022-10-07'),
(11, '778899002', 'Arif Saputra', 'AMS133', '12345', '4', '6', '2022-10-07'),
(12, '112233447', 'Ria Amelia', 'AMS135', '12345', '4', '6', '2022-10-07'),
(13, '556677891', 'Agus Setiawan', 'AMS144', '12345', '4', '6', '2022-10-07'),
(14, '990011225', 'Wulan Sari', 'AMS148', '12345', '4', '6', '2022-10-07'),
(15, '334455669', 'Ade Rahman', 'AMS151', '12345', '4', '6', '2022-10-07'),
(16, '778899003', 'Siti Nurjanah', 'AMS159', '12345', '4', '6', '2022-10-07'),
(17, '112233448', 'Fajar Wijaya', 'AMS161', '12345', '4', '6', '2022-10-07');

-- --------------------------------------------------------

--
-- Table structure for table `tblsemester`
--

CREATE TABLE `tblsemester` (
  `Id` int(10) NOT NULL,
  `semester` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsemester`
--

INSERT INTO `tblsemester` (`Id`, `semester`) VALUES
(1, 'Pertama'),
(2, 'Kedua'),
(3, 'Ketiga');

-- --------------------------------------------------------

--
-- Table structure for table `tbltahunajaran`
--

CREATE TABLE `tbltahunajaran` (
  `Id` int(10) NOT NULL,
  `tahunAjaran` varchar(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `aktif` varchar(10) NOT NULL,
  `dataMasuk` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltahunajaran`
--

INSERT INTO `tbltahunajaran` (`Id`, `tahunAjaran`, `semester`, `aktif`, `dataMasuk`) VALUES
(1, '2021/2022', '1', '1', '2022-10-31'),
(3, '2021/2022', '2', '0', '2022-10-31'),
(4, '2022/2023', '2', '0', '2023-10-31'),
(5, '2023/2024', '2', '0', '2024-10-31'),
(6, '2022/2023', '1', '0', '2023-10-31'),
(7, '2023/2024', '1', '0', '2024-10-31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblattendance`
--
ALTER TABLE `tblattendance`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblguru`
--
ALTER TABLE `tblguru`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblkelas`
--
ALTER TABLE `tblkelas`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblkodekelas`
--
ALTER TABLE `tblkodekelas`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblmurid`
--
ALTER TABLE `tblmurid`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblsemester`
--
ALTER TABLE `tblsemester`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbltahunajaran`
--
ALTER TABLE `tbltahunajaran`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblattendance`
--
ALTER TABLE `tblattendance`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT for table `tblguru`
--
ALTER TABLE `tblguru`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblkelas`
--
ALTER TABLE `tblkelas`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblkodekelas`
--
ALTER TABLE `tblkodekelas`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblmurid`
--
ALTER TABLE `tblmurid`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblsemester`
--
ALTER TABLE `tblsemester`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbltahunajaran`
--
ALTER TABLE `tbltahunajaran`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
